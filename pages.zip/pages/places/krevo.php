<?PHP  header("Content-Type: text/html; charset=utf-8");?>
<!DOCTYPE html>
<html lang="ru">
  <head>

<!-- ***Include Header*** -->
<? include ("../_include/header_places.php"); ?>
  
  <!-- ***Content & Sidebars*** -->
  <div class="container-fluid">
  

      <!-- ***Sidebar Left - include CurrentDir*** -->
<? include ("../_include/dir_places.php"); ?>

	
    <!-- ***Page Content*** -->
    <div class="col-md-8">
		<h3>Крево</h3>
		<p>
			Статья на 6000 знаков (с пробелами)</br></br>
			У жніўні 1385 г. у Крэва — радавы замак Ягайлы, прыбылі паслы Польшчы кракаўскі чашнік Улодка, 
			завіхосцкі кашталян Мікалай, казімірскі дзяржаўца Крысцін і паслы Венгрыі чанадскі прэпазіт Стафан і патацкі кашталян Ладзіслаў, 
			сын Какаса дэ Каза. 14 жніўня таго ж года было падпісана пагадненне з Польшчай, што вядома пад умоўнай назвай «Крэўская унія».
		
		</p>
	</div>
	
	<!-- ***Sidebar Right*** -->

	<? include ("../_include/right_sidebar_places.php"); ?>

	
</div>

<!-- ***Include Footer*** -->
<? include ("../_include/footer.php"); ?>
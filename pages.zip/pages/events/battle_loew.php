<?PHP  header("Content-Type: text/html; charset=utf-8");?>
<!DOCTYPE html>
<html lang="ru">
  <head>

<!-- ***Include Header*** -->
<? include ("../_include/header_events.php"); ?>
  
  <!-- ***Content & Sidebars*** -->
  <div class="container-fluid">
  

      <!-- ***Sidebar Left - include CurrentDir*** -->
<? include ("../_include/dir_events.php"); ?>

	
    <!-- ***Page Content*** -->
    <div class="col-md-8">
		<h3>Битвы под Лоевом, 1649 и 1651</h3>
		
		<p>
		Context		
		</p>
		
		<p class="img-float-left">
		<img src="../../images/img-events/#"/>
		</p>
		
		</br></br></br>
		<p><small>
		be-x-old.wikipedia.org</br>
		be.wikipedia.org</br>
		pl.wikipedia.org</br>
		uk.wikipedia.org</br>
		ru.wikipedia.org</br>
		</small></p>
		
	</div>
	
	<!-- ***Sidebar Right*** -->

	<? include ("../_include/right_sidebar_events.php"); ?>

	
</div>

<!-- ***Include Footer*** -->
<? include ("../_include/footer.php"); ?>
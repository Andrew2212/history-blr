
      <div class="col-md-2 right-bar">
	   <p>
			<img src="../../images/img-places/wilno.jpg" class="img-right-120"/></br>
			<small><a href="wilno.php">Вильно</a></small></br></br>
	   </p>
	   <p>
			<img src="../../images/img-places/brama.jpg" class="img-right-120"/></br>
			<small><a href="wostra_brama.php">Вострая Брама</a></small></br></br>
	   </p>
	   <p>
			<img src="../../images/img-places/orsha_field.jpg" class="img-right-120"/></br>
			<small><a href="krapiwen_field.php">Крапивенское поле</a></small></br></br>
	   </p>
	   <p>
			<img src="../../images/img-places/kossovo.jpg" class="img-right-120"/></br>
			<small><a href="kossowo.php">Коссово</a></small></br></br>
	   </p>
	   <p>
			<img src="../../images/img-places/samogitia.jpg" class="img-right-120"/></br>
			<small><a href="samogitia.php">Жемайтия (Самогития)</a></small></br></br>
	   </p>	 
	   <p>
			<img src="../../images/img-places/nowogrudok.jpg" class="img-right-120"/></br>
			<small><a href="nowogrudok.php">Новогрудок</a></small></br></br>
	   </p>	   
	  </div>
	
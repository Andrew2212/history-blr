
      <div class="col-md-2 left-bar">
      <ul>

          <h4>Люди</h4>

        <li>
          <a href="you.php">Лично ТЫ и история</a>
        </li>
		<li>
          <a href="bogdanowich.php" class="item-edit">Богданович Максим</a>
        </li>
        <li>
          <a href="bulak.php" class="item-edit">Булак-Балахович</a>
        </li>
		<li>
          <a href="vitovt.php" class="item-edit">Великий князь Литовский Витовт</a>
        </li>
        <li>
          <a href="gedimin.php" class="item-edit">Великий князь Литовский Гедимин</a>
        </li>
        <li>
          <a href="mindowg.php" class="item-edit">Великий князь Литовский Миндовг</a>
        </li>
        <li>
          <a href="olgerd.php" class="item-edit">Великий князь Литовский Ольгерд</a>
        </li>
        <li>
          <a href="svidrigailo.php" class="item-edit">Великий князь Литовский Свдригайло</a>
        </li>
        <li>
          <a href="shwarn.php" class="item-edit">Великий князь Литовский Шварн</a>
        </li>
        <li>
          <a href="volovicz.php" class="item-edit">Волович Евстафий,  епископ виленский, меценат и библиофил</a>
        </li>
        <li>
          <a href="charadzej.php" class="item-edit">Всеслав Чародей</a>
        </li>
        <li>
          <a href="gusowsky.php" class="item-edit">Гусовский Николай, поэт раннего Ренессанса</a>
        </li>
        <li>
          <a href="gonsewsky.php" class="item-edit">Александр Корвин Гонсевский, комендант Кремля, 1610и</a>
        </li>
        <li>
          <a href="david.php" class="item-edit">Давид Городенский</a>
        </li>
		<li>
          <a href="domeyko.php" class="item-edit">Домейко Игнацы, национальный герой Чили</a>
        </li>
		<li>
          <a href="#" class="item-unable">Достоевский Ф. М.</a>
        </li>
        <li>
          <a href="efrosinia.php" class="item-edit">Ефросиния Полоцкая</a>
        </li>
		<li>
          <a href="kalinowski.php" class="item-edit">Калиновский Кастусь</a>
        </li>
        <li>
          <a href="kirill_tur.php" class="item-edit">Кирилл Туровский</a>
        </li>
        <li>
          <a href="kostiushko.php" class="item-edit">Костюшко Тадеуш, национальный герой США</a>
        </li>
		<li>
          <a href="konashewicz.php" class="item-edit">Конашевич-Сагайдачный, гетман Войска Запорожского</a>
        </li>
        <li>
          <a href="#" class="item-unable">Коненков С. Т., скульптор</a>
        </li>
        <li>
          <a href="kunciewicz.php" class="item-edit">Иософат Кунцевич, архиепископ Полоцкий</a>
        </li>
        <li>
          <a href="lisowsky.php" class="item-edit">Лисовский-Янович А. Ю., полковник "лисовчиков", 1608-1616</a>
        </li>
        <li>
          <a href="kishky.php" class="item-edit">Магнатский род </br>— Кишки</a>
        </li>
        <li>
          <a href="kesgajla.php" class="item-edit">Магнатский род </br>— Кезгайлы</a>
        </li>
        <li>
          <a href="pacy.php" class="item-edit">Магнатский род </br>— Пацы</a>
        </li>
        <li>
          <a href="radziwilly.php" class="item-edit">Магнатский род </br>— Радзивиллы</a>
        </li>
        <li>
          <a href="kesgaila.php" class="item-edit">Магнатский род </br>— Кезгайлы</a>
        </li>
        <li>
          <a href="sapegi.php" class="item-edit">Магнатский род </br>— Сапеги</a>
        </li>
        <li>
          <a href="oginskie.php" class="item-edit">Магнатский род </br>— Огинские</a>
        </li>
        <li>
          <a href="mickiewicz.php" class="item-edit">Мицкевич Адам</a>
        </li>
        <li>
        <a href="#" class="item-unable">Минейко Зигмунд, почетный гражданин Греции</a>
        </li>
        <li>
          <a href="narkewicz.php" class="item-edit">Наркевич-Иодко, "электрический человек" — профессор электрографии и магнетизма</a>
        </li>
        <li>
          <a href="ostrogski.php" class="item-edit">Острожский Константин, гетман великий литовский</a>
        </li>
        <li>
          <a href="przewalskij.php" class="item-edit">Пржевальский Н. М., путешевтвенник и натуралист</a>
        </li>
        <li>
          <a href="rejtan.php" class="item-edit">Рейтан Тадеуш, Дон Кихот Речи Посполитой</a>
        </li>
        <li>
          <a href="rogvolod_rogneda.php" class="item-edit">Рогволод и Рогнеда</a>
        </li>
        <li>
          <a href="sapega.php" class="item-edit">Сапега Лев Иванович</a>
        </li>
        <li>
          <a href="simienowicz.php" >Семенович Казимир, основопложник ракетостроения</a>
        </li>
        <li>
          <a href="skorina.php" class="item-edit">Скорина, литвин из Полоцка</a>
        </li>
		<li>
          <a href="skosyrew.php" class="item-edit">Скосырев Б. М., король Андорры</a>
        </li>
        <li>
          <a href="sudzilowskij.php" class="item-edit">Судзиловский Н. К., президент сената Территории Гавайи</a>
        </li>
        <li>
          <a href="stankewicz.php" class="item-edit">Станкевич Ян, историк, основатель Великолитовского фонда им. Льва Сапеги</a>
        </li>
        <li>
          <a href="torwald.php" class="item-edit">Торвальд Кодранссон, креститель Полоцка</a>
        </li>
		<li>
          <a href="hodkewich.php" class="item-edit">Ходкевичи, воины великого княжества</a>
        </li>
        <li>
          <a href="shagal.php" class="item-edit">Шагал Марк, художник</a>
        </li>
        <li>
          <a href="#" class="item-unable">Шостакович Д. Д., композитор</a>
        </li>
        <li>
          <a href="fedorow.php" class="item-edit">Федоров Иван, первопечатник в Московии и Украине</a>
        </li>
		<li>
          <a href="jagellony.php" class="item-edit">Ягеллоны</a>
        </li>
		<li>
          <a href="jagiello.php" class="item-edit">Ягайло</a>
        </li>
		<li>
          <a href="#" class="item-unable">Some link</a>
        </li>
		<li>
          <a href="#" class="item-unable">Some link</a>
        </li>
        <li>
          <a href="#" class="item-unable">...</a>
        </li>
        <li>
          <a href="#" class="item-unable">Some link</a>
        </li>
      </ul>
	  </div>
	
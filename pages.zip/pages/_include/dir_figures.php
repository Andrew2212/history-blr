
      <div class="col-md-2 left-bar">
      <ul>

          <h4>Люди</h4>

        <li>
          <a href="you.php">Лично ТЫ и история</a>
        </li>
		<li>
          <a href="bogdanowich.php" class="item-edit">Богданович Максим</a>
        </li>
        <li>
          <a href="bulak.php" class="item-edit">Булак-Балахович</a>
        </li>
		<li>
          <a href="vitovt.php" class="item-edit">Витовт</a>
        </li>
		<li>
          <a href="domeyko.php" class="item-edit">Домейко Игнацы, национальный герой Чили</a>
        </li>
		<li>
          <a href="#" class="item-unable">Достоевский Ф. М.</a>
        </li>
		<li>
          <a href="kalinowski.php" class="item-edit">Калиновский Кастусь</a>
        </li>
        <li>
          <a href="kostiushko.php" class="item-edit">Костюшко Тадеуш, национальный герой США</a>
        </li>
		<li>
          <a href="#" class="item-unable">Конашевич-Сагайдачный, гетман Войска Запорожского</a>
        </li>
        <li>
          <a href="kesgajla.php" class="item-edit">Кезгайло</a>
        </li>
       	<li>
          <a href="mindowg.php" class="item-edit">Миндовг</a>
        </li>
		<li>
          <a href="olgerd.php" class="item-edit">Ольгерд</a>
        </li>
    	<li>
          <a href="oginski_mihail_hetman.php" class="item-edit">Огинский Михаил, гетман великий литовский</a>
        </li>
        <li>
          <a href="ostrogski.php" class="item-edit">Острожский Константин, гетман великий литовский</a>
        </li>
        <li>
          <a href="pac_hetman.php" class="item-edit">Пац Михаил, гетман великий литовский</a>
        </li>
        <li>
          <a href="#" class="item-unable">Радзивиллы</a>
        </li>
        <li>
          <a href="radziwill_cherny.php" class="item-edit">Радзивилл Николай "Черный", канцлер великий Литовский</a>
        </li>
        <li>
          <a href="radziwill_herkules.php" class="item-edit">Радзивилл Юрий "Геркулес", гетман великий Литовский</a>
        </li>
        <li>
          <a href="radziwill_sirotka.php" class="item-edit">Радзивилл Николай Криштоф (Сиротка)</a>
        </li>
        <li>
          <a href="sapega.php" class="item-edit">Сапега Лев Иванович</a>
        </li>
        <li>
          <a href="skorina.php" class="item-edit">Скорина, литвин из Полоцка</a>
        </li>
		<li>
          <a href="#" class="item-unable">Скосырев Б. М., король Андорры</a>
        </li>
		<li>
          <a href="hodkewich.php" class="item-edit">Ходкевич Ян Кароль, гетман великй литовский</a>
        </li>
		<li>
          <a href="jagellony.php" class="item-edit">Ягеллоны</a>
        </li>
		<li>
          <a href="jagiello.php" class="item-edit">Ягайло</a>
        </li>
		<li>
          <a href="#" class="item-unable">Some link</a>
        </li>
		<li>
          <a href="#" class="item-unable">Some link</a>
        </li>
        <li>
          <a href="#" class="item-unable">...</a>
        </li>
        <li>
          <a href="#" class="item-unable">Some link</a>
        </li>
      </ul>
	  </div>
	
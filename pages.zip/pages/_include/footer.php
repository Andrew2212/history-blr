<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
	<!-- ***Footer*** -->
<div class="container-fluid">
    <ul class="nav nav-list">
        <!--It's just line-->
        <li class="nav-divider"></li>
    </ul>

    <nav id="footer">
        <form>
        <div class="col-md-2">

			<!-- HotLog -->
			<span id="hotlog_counter"></span>
			<span id="hotlog_dyn"></span>
			<script type="text/javascript"> var hot_s = document.createElement('script');
			hot_s.type = 'text/javascript'; hot_s.async = true;
			hot_s.src = 'http://js.hotlog.ru/dcounter/2447103.js';
			hot_d = document.getElementById('hotlog_dyn');
			hot_d.appendChild(hot_s);
			</script>
			<noscript>
			<a href="http://click.hotlog.ru/?2447103" target="_blank">
			<img src="http://hit6.hotlog.ru/cgi-bin/hotlog/count?s=2447103&im=79" border="0" 
			title="HotLog" alt="HotLog"></a>
			</noscript>
			<!-- /HotLog -->
		</div>
			
		<div class="col-md-4">
			 <!--***Add SocialNet link from Yandex***-->
			<script type="text/javascript" src="//yastatic.net/share/share.js" charset="utf-8"></script><div class="yashare-auto-init" data-yashareL10n="ru" data-yashareType="link" data-yashareQuickServices="vkontakte,facebook,twitter,odnoklassniki,moimir,lj,friendfeed,moikrug,gplus,surfingbird"></div>
			<!--/***Add SocialNet link from Yandex***-->
        </div>
        
        <div class="col-md-4">
        Сайт в социальных сетях 
        <a href="https://twitter.com/Belbriefhistory" target="blanc">
		<img src="../../images/_img-icons/twitter.png" title="Twitter" width="32">
		</a>
        </div>

		<div class="col-md-2">  
			<span style="float: right;"> ProjectStudio <a href="#"></a>
			</span>
		</div>
		
        </form>
    </nav>

	<div class="col-md-12">
    <ul class="nav nav-list">
        <!--It's just line-->
        <li class="nav-divider"></li>
    </ul>
    </div>
    
    <div class="col-md-12" style="text-align: center">
    	<p>
		<small>Эл. почта для писем </small>
		 <font style="color:#F00;"> history.msg<img src="../../images/img-about/dog.jpg"/>gmail.com</font>
		</p>
    </div>
    
</div>
	<!-- /***Footer*** -->
	
  <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
  <script src="https://code.jquery.com/jquery.js"></script> 
  <!-- Include all compiled plugins (below), or include individual files as needed --> 
  <script src="../../js/bootstrap.min.js"></script>
  
  
  </body>
</html>
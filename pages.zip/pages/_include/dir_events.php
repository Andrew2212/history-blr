
      <div class="col-md-2 left-bar">
      <ul>

          <h4>События</h4>

        <li>
          <a href="sinie_wody.php" class="item-edit">Битва на Синих Водах 1362 г.</a>
        </li>
        <li>
          <a href="orsha_battle.php" class="item-edit">Битва под Оршей 1514 г.</a>
        </li>
        <li>
          <a href="#" class="item-unable">Битва при Клушине 1610 г.</a>
        </li>
        <li>
          <a href="battle_kircholm.php" class="item-edit">Битва под Киргхольмом</a>
        </li>
        <li>
          <a href="battle_hotin.php" class="item-edit">Битва под Хотином</a>
        </li>
        <li>
          <a href="uprising_1830.php" class="item-edit">Восстание 1830 года</a>
        </li>
        <li>
          <a href="uprising_1863.php" class="item-edit">Восстание 1863-1864 года (Восстание Калиновского)</a>
        </li>
        <li>
          <a href="confederacia_warshawa.php" class="item-edit">Варшавская конфедерация 1573 г.</a>
        </li>
        <li>
          <a href="world_war_1.php" class="item-edit">Война Первая мировая</a>
        </li>
        <li>
          <a href="world_war_2.php" class="item-edit">Война Вторая мировая</a>
        </li>
        <li>
          <a href="war_1812.php" class="item-edit">Война 1812 года</a>
        </li>
        <li>
          <a href="war_green_oak.php" class="item-edit">Война "Зеленого дуба"</a>
        </li>
        <li>
          <a href="grunwald.php" class="item-edit">Грюнвальдская битва 1410 г.</a>
        </li>
        <li>
          <a href="unia_krewo.php" class="item-edit">Кревская уния 1385 г.</a>
        </li>
        <li>
          <a href="blood_potop.php" class="item-edit">Кровавый Потоп 1655-1660 г.</a>
        </li>
		<li>
          <a href="unia_liublin.php" class="item-edit">Люблинская уния 1569 г.</a>
        </li>
        <li>
          <a href="razbor_rechi.php" class="item-edit">Разделы Речи Посполитой 1772-1795 г</a>
        </li>
        <li>
          <a href="uprising_sluzk.php" class="item-edit">Слуцкое восстание</a>
        </li>
        <li>
          <a href="fails.php" class="item-edit">Неудачные попытки</a>
        </li>
        <li>
          <a href="#" class="item-unable">Some link</a>
        </li>
		<li>
          <a href="#" class="item-unable">Some link</a>
        </li>
        <li>
          <a href="#" class="item-unable">...</a>
        </li>
        <li>
          <a href="#" class="item-unable">Some link</a>
        </li>
      </ul>
	  </div>
	
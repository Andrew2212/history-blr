
      <div class="col-md-2 left-bar">
      <ul>

          <h4>События</h4>

        <li>
          <a href="sinie_wody.php" class="item-edit">Битва на Синих Водах, 1362, (с Золотой Ордой)</a>
        </li>
        <li>
          <a href="battle_worskla.php" class="item-edit">Битва на Ворскле, 1399, (с Золотой Ордой)</a>
        </li>
        <li>
          <a href="grunwald.php" class="item-edit">Битва под Грюнвальдом, 1410, (с Тевтонским Орденом)</a>
        </li>
        <li>
          <a href="orsha_battle.php" class="item-edit">Битва под Оршей, 1514, (с Московией)</a>
        </li>
        <li>
          <a href="battle_ula.php" class="item-edit">Битва при Чашниках (Битва на Уле), 1564, (с Московией)</a>
        </li>
        <li>
          <a href="#" class="item-unable">Битва при Клушине, 1610, (с Московией)</a>
        </li>
        <li>
          <a href="battle_kircholm.php" class="item-edit">Битва под Киргхольмом, 1605, (со Швецией)</a>
        </li>
        <li>
          <a href="battle_loew.php" class="item-edit">Битвы под Лоевом, 1649 и 1651, (с Войском Запорожским)</a>
        </li>
        <li>
          <a href="#" class="item-unable">Битва под Ляховичами (осада), 1660, (с Московией)</a>
        </li>
        <li>
          <a href="battle_nemiga.php" class="item-edit">Битва на Немиге, 1067, (Всеслав Чародей против Рюриковичей)</a>
        </li>
        <li>
          <a href="battle_polonka.php" class="item-edit">Битва под Полонкой, 1660, (с Московией)</a>
        </li>
        <li>
          <a href="battle_hotin.php" class="item-edit">Битвы под Хотином, 1621 и 1673, (с Османской Империей)</a>
        </li>
        <li>
          <a href="uprising_1794.php" class="item-edit">Восстание Костюшо 1830 года</a>
        </li>
        <li>
          <a href="uprising_1830.php" class="item-edit">Восстание 1830 года</a>
        </li>
        <li>
          <a href="uprising_1863.php" class="item-edit">Восстание 1863-1864 года (Восстание Калиновского)</a>
        </li>
        <li>
          <a href="confederacia_warshawa.php" class="item-edit">Конфедерация Варшавская, 1573, (равенство всех религий)</a>
        </li> 
		<li>
          <a href="constitution_3may.php" class="item-edit">Конституция 3 мая 1791 года (отмена "шляхетской демократии")</a>
        </li>      
        <li>
          <a href="world_war_1.php" class="item-edit">Война Первая мировая</a>
        </li>
        <li>
          <a href="world_war_2.php" class="item-edit">Война Вторая мировая</a>
        </li>
        <li>
          <a href="war_1812.php" class="item-edit">Война 1812 года</a>
        </li>
        <li>
          <a href="war_civil_1432.php" class="item-edit">Война гражданская в ВКЛ 1432—1438</a>
        </li>
        <li>
          <a href="war_civil_1696.php" class="item-edit">Война гражданская в ВКЛ 1696—1702</a>
        </li>
        <li>
          <a href="war_livonia.php" class="item-edit">Война Ливонская, 1558-1583, (с Московией)</a>
        </li>
        <li>
          <a href="war_great_north.php" class="item-edit">Война Великая Северная, 1700-1721, (со Швецией и Московией)</a>
        </li>
        <li>
          <a href="war_green_oak.php" class="item-edit">Война "Зеленого дуба"</a>
        </li>
        <li>
          <a href="blood_potop.php" class="item-edit">Кровавый Потоп 1655-1660 г.</a>
        </li>	
        <li>
          <a href="razbor_rechi.php" class="item-edit">Разделы Речи Посполитой 1772-1795 г</a>
        </li>
        <li>
          <a href="uprising_sluzk.php" class="item-edit">Слуцкое восстание</a>
        </li>
        <li>
          <a href="fails.php" class="item-edit">Неудачные попытки</a>
        </li>
        <li>
          <a href="unia_vilno.php" class="item-edit">Уния Виленско-Радомская 1401 г.</a>
        </li>
        <li>
          <a href="unia_gorodlo.php" class="item-edit">Уния Городельская 1413 г.</a>
        </li>
        <li>
          <a href="unia_krewo.php" class="item-edit">Уния Кревская 1385 г.</a>
        </li>
        <li>
          <a href="unia_liublin.php" class="item-edit">Уния Люблинская 1569 г.</a>
        </li>
        <li>
          <a href="#" class="item-unable">Some link</a>
        </li>
		<li>
          <a href="#" class="item-unable">Some link</a>
        </li>
        <li>
          <a href="#" class="item-unable">...</a>
        </li>
        <li>
          <a href="#" class="item-unable">Some link</a>
        </li>
      </ul>
	  </div>
	

      <div class="col-md-2 right-bar">
	   <p>
			<img src="../../images/img-figures/olgerd.jpg" class="img-right-120"/></br>
			<small><a href="../figures/olgerd.php">Князь Ольгерд</a></small></br></br>
	   </p>
		<p>
			<img src="../../images/img-figures/sapega.jpg" class="img-right-120"/></br>
			<small><a href="../figures/sapega.php">Лев Сапега</a>, великй гетман Литовский</small></br></br>
	   </p>
	   	<p>
		<img src="../../images/img-figures/simienowicz.jpg" class="img-right-120"/></br>
			<small><a href="../figures/simienowicz.php">Казимир Семенович</a>, пионер ракетостроения</small></br></br>
	   </p>
	   	<p>
			<img src="../../images/img-figures/hodkewich.jpg" class="img-right-120"/></br>
			<small><a href="../figures/hodkewich.php">Янг Кароль Ходкевич</a>, великй гетман Литовский</small></br></br>
	   </p>
	   	<p>
		<img src="../../images/img-figures/skorina.jpg" class="img-right-120"/></br>
			<small><a href="../figures/skorina.php">Франциск Скорина</a></small></br></br>
	   </p>
	   	<p>
		<img src="../../images/img-figures/kostiushko.jpg" class="img-right-120"/></br>
			<small><a href="../figures/kostiushko.php">Тадеуш Бонавентура Костюшко</a></small></br></br>
	   </p>
	   <p>
		<img src="../../images/img-figures/kalinowski.jpg" class="img-right-120"/></br>
			<small><a href="../figures/kalinowski.php">Кастусь Калиновский</a></small></br></br>
	   </p>
	   	<p>
		<img src="../../images/img-figures/domeyko.jpg" class="img-right-120"/></br>
			<small><a href="../figures/domeyko.php">Игнаци Домейко</a></small></br></br>
	   </p>

	  </div>
	
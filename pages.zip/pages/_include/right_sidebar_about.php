
 <div class="col-md-2 right-bar">
      <ul style="text-align: left">

          <h4>Материалы предоставили</h4>

		<li>
          <a href="http://be-x-old.wikipedia.org">be-x-old.wikipedia.org</a>
        </li>
		<li>
          <a href="http://be.wikipedia.org" >be.wikipedia.org</a>
        </li>
		<li>
          <a href="http://pl.wikipedia.org" >pl.wikipedia.org</a>
        </li>
		<li>
          <a href="http://uk.wikipedia.org">uk.wikipedia.org</a>
        </li>
        <li>
          <a href="http://lt.wikipedia.org">lt.wikipedia.org</a>
        </li>
		<li>
          <a href="http://ru.wikipedia.org">ru.wikipedia.org</a>
        </li>
        <li>
          <a href="http://coollib.com/b/277966/read">Краткий курс истории Беларуси IX-XXI веков. А. Тарас</a>
        </li>
        <li>
          <a href="http://dodontitikaka.ucoz.com/" >Великое Княжество Литовское как наследие Беларусов</a>
        </li>
        <li>
          <a href="http://histmuseum.by/">Национальный исторический музей РБ</a>
        </li>
		<li>
          <a href="http://www.karty.by/">karty.by</a>
        </li>
        <li>
          <a href="http://yan-k.livejournal.com">Ян Карпов</a>
        </li>
		<li>
          <a href="http://czeslaw-list.livejournal.com/tag/%D0%91%D0%B5%D0%BB%D0%B0%D1%80%D1%83%D1%81%D1%8C">czeslaw-list.livejournal.com</a>
        </li>
        <li>
          <a href="http://inbelhist.org">inbelhist.org</a>
        </li>
		<li>
          <a href="http://adverbum.org/">AdVerbum.org</a>
        </li>
        <li>
          <a href="http://www.istpravda.ru/bel/">Историческая правда</a>
        </li>
		<li>
          <a href="http://inbelhist.org/">Інстытут беларускай гісторыі і культуры</a>
        </li>
        <li>
          <a href="http://90s.by/">Беларусь. 90's</a>
        </li>
        <li>
          <a href="#" class="item-unable">Some link</a>
        </li>
		<li>
          Памятники искусства Советского Союза: Белоруссия, Литва, Латвия, Эстония, ББК 85.113(2)1 Б43
        </li>
        <li>
          <a href="../download/kraina_blr.php">Краiна Беларусь</a>, ISBN 978-985-6919-82-7
        </li>
        <li>
          Краiна Беларусь. Вялiкае Княства Лiтоўскае, ISBN 978-80-8101-602-8
        </li>
        <li>
          Гiстарычны атлас Беларусi, ISBN 978-83-916658-4-8
        </li>
      </ul>
	  </div>
	
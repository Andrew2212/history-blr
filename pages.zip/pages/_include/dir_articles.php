
      <div class="col-md-2 left-bar">
      <ul>

          <h4>Статьи</h4>

        <li>
          <a href="book_mova.php">Хорошая горькая книга</a>
        </li>
        <li>
          <a href="http://www.charter97.org/ru/news/2013/9/18/75920/">Белорусоцентристский взгляд на историю</a>
        </li>
        <li>
          <a href="rus_mir.php">МГУ им. Ломоносова: <i>— "Никакой белорусской традиции нет"</i></a>
        </li>
        <li>
          <a href="bnr_article.php">Могла ли БНР удержаться?</a>
        </li>
        <li>
          <a href="essay.php">Эссе на заданную тему</a>
        </li>
        <li>
          <a href="old_bel_shliahta.php">СРЭБНАЯ СТРАЛА Ў ЧЫРВОНЫМ ПОЛІ</a>
        </li>
        <li>
          <a href="#" class="item-unable">Some link</a>
        </li>
        <li>
          <a href="#" class="item-unable">Some link</a>
        </li>
		<li>
          <a href="#" class="item-unable">Some link</a>
        </li>
        <li>
          <a href="#" class="item-unable">...</a>
        </li>
        <li>
          <a href="#" class="item-unable">Some link</a>
        </li>
      </ul>
	  </div>
	

      <div class="col-md-2 left-bar">
      <ul>

          <h4>Статьи</h4>

        <li>
          <a target="_blank" href="http://nn.by/?c=ar&i=125014&lang=ru">Откровения националиста [nn.by Лучшее за 2014 г.]</a>
        </li>
        <li>
          <a href="nation_id.php">Национальная идентификация</a>
        </li>
        <li>
          <a target="_blank" href="http://www.charter97.org/ru/news/2013/9/18/75920/">Белорусоцентристский взгляд на историю</a>
        </li>
        <li>
          <a href="rus_mir.php">МГУ им. Ломоносова: <i>— "Никакой белорусской традиции нет"</i></a>
        </li>
        <li>
          <a href="bnr_article.php">Могла ли БНР удержаться?</a>
        </li>
        <li>
          <a href="essay.php">Эссе на заданную тему</a>
        </li>
        <li>
          <a href="old_bel_shliahta.php">СРЭБНАЯ СТРАЛА Ў ЧЫРВОНЫМ ПОЛІ</a>
        </li>
        <li>
          <a href="blr_family_names.php">Наши фамилии</a>
        </li>
        <li>
          <a href="book_mova.php">Хорошая горькая книга</a>
        </li>
		<li>
          <a href="#" class="item-unable">Нация — элита vs крестьяство</a>
        </li>
        <li>
          <a href="#" class="item-unable">Иностранный компонент в белорусской культуре</a>
        </li>
        <li>
          <a href="#" class="item-unable">...</a>
        </li>
        <li>
          <a href="#" class="item-unable">Some link</a>
        </li>
      </ul>
	  </div>
	
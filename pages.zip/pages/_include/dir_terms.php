
      <div class="col-md-2 left-bar">
      <ul>

          <h4>Термины</h4>

		<li>
          <a href="blr_etnos.php">Белорусский этнос</a>
        </li>
		<li>
          <a href="bnr.php">БНР</a>
        </li>
		<li>
          <a href="bssr.php" class="item-edit">БССР</a>
        </li>
       	<li>
          <a href="alba_rusia.php" class="item-edit">Белая Русь и белоруссы</a>
        </li>
		<li>
          <a href="wkl.php" class="item-edit">Великое княжество Литовское</a>
        </li>
		<li>
          <a href="weliki_hetman.php" class="item-link">Великий гетман литовский</a>
        </li>
		<li>
          <a href="weliki_kancler.php" class="item-link">Великий канцлер литовский</a>
        </li>
		<li>
          <a href="weliki_marshalok.php" class="item-link">Великий маршалок литовский</a>
        </li>
        <li>
          <a href="yotving.php">Готы, ятвяги, пруссы</a>
        </li>
        <li>
          <a href="gudai.php">Гуды и Белая Русь</a>
        </li>
        <li>
          <a href="zemiane.php">Земяне и панцирные бояре</a>
        </li>
		<li>
          <a href="kalumny.php" class="item-edit">Калюмны</a>
        </li>
		<li>
          <a href="husaria.php" class="item-edit">Крылатые гусары</a>
        </li>
		<li>
          <a href="litwiny.php" class="item-edit">Литвины</a>
        </li>
        <li>
          <a href="#" class="item-unable">Литовец, белорусец</a>
        </li>
        <li>
          <a href="myths.php" class="item-edit">Мифы про историю</a>
        </li>
        <li>
          <a href="blr_gerb.php" class="item-edit">Национальный герб Беларуси</a>
        </li>
        <li>
          <a href="blr_hymn.php" class="item-edit">Национальный гимн Беларуси</a>
        </li>
        <li>
          <a href="blr_flag.php">Национальный флаг Беларуси</a>
        </li>
        <li>
          <a href="polotsk_principality.php" class="item-edit">Полоцкое княжество</a>
        </li>
        <li>
          <a href="blr_gerb.php" class="item-edit">Погоня</a>
        </li>
        <li>
          <a href="rzeczpospolita.php" class="item-edit">Речь Посполитая</a>
        </li>
		<li>
          <a href="rzeczpospolita_treh_narodov.php">Речь Посполитая Трех Народов</a>
        </li>
		<li>
          <a href="rb.php" class="item-edit">Республика Беларусь</a>
        </li>
        <li>
          <a href="ross_empire.php" class="item-edit">Российская империя</a>
        </li>
        <li>
          <a href="sssr.php" class="item-edit">СССР</a>
        </li>
        <li>
          <a href="slavs.php">Славяне</a>
        </li>
		<li>
          <a href="statut.php" class="item-edit">Статут ВКЛ</a>
        </li>
        <li>
          <a href="sewero_zapadny_kraj.php" class="item-edit">Северо-Западный край</a>
        </li>
		<li>
          <a href="shliahta.php">Шляхта</a>
        </li>
		<li>
          <a href="#" class="item-unable">Магдебургское право</a>
        </li>
		<li>
          <a href="#" class="item-unable">Шляхетская демократия</a>
        </li>
		<li>
          <a href="#" class="item-unable">Some link</a>
        </li>
		<li>
          <a href="#" class="item-unable">Some link</a>
        </li>
		<li>
          <a href="#" class="item-unable">Some link</a>
        </li>
		<li>
          <a href="#" class="item-unable">Some link</a>
        </li>		
        <li>
          <a href="#" class="item-unable">...</a>
        </li>
        <li>
          <a href="#" class="item-unable">Some link</a>
        </li>
      </ul>
	  </div>
	
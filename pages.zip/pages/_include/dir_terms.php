
      <div class="col-md-2 left-bar">
      <ul>

          <h4>Термины</h4>

		<li>
          <a href="blr_etnos.php">Белорусский этнос</a>
        </li>
        <li>
          <a href="belarus.php">Беларусь</a>
        </li>
		<li>
          <a href="bnr.php">БНР</a>
        </li>
		<li>
          <a href="bssr.php" class="item-edit">БССР</a>
        </li>
		<li>
          <a href="wkl.php" class="item-edit">Великое княжество Литовское</a>
        </li>
		<li>
          <a href="weliki_hetman.php">Великий гетман литовский</a>
        </li>
		<li>
          <a href="weliki_kancler.php">Великий канцлер литовский</a>
        </li>
        <li>
          <a href="dukes_wkl.php" class="item-edit">Великий князь литовский</a>
        </li>
		<li>
          <a href="weliki_marshalok.php">Великий маршалок литовский</a>
        </li>
        <li>
          <a href="yotving.php">Готы, ятвяги, пруссы, венеды</a>
        </li>
        <li>
          <a href="gudai.php">Гуды и Белая Русь</a>
        </li>
        <li>
          <a href="dwina_stouns.php" class="item-edit">Двинские (Борисовы) камни</a>
        </li>
        <li>
          <a href="zemiane.php">Земяне и панцирные бояре</a>
        </li>
        <li>
          <a href="jesuity.php" class="item-edit">Иезуиты. Последний оплот.</a>
        </li>
		<li>
          <a href="kalumny.php" class="item-edit">Калюмны</a>
        </li>
        <li>
          <a href="efrosinia_rood.php" class="item-edit">Крест Ефросинии Полоцкой</a>
        </li>
		<li>
          <a href="husaria.php" class="item-edit">Крылатые гусары</a>
        </li>
		<li>
          <a href="litwiny.php">Литвины</a>
        </li>
        <li>
          <a href="lutizy.php">Лютичи, полабские славяне</a>
        </li>
        <li>
          <a href="magdeburg_law.php" class="item-edit">Магдебургское право</a>
        </li>
        <li>
          <a href="myths.php" class="item-edit">Мифы про историю</a>
        </li>
        <li>
          <a href="blr_gerb.php" class="item-edit">Национальный герб Беларуси</a>
        </li>
        <li>
          <a href="blr_hymn.php" class="item-edit">Национальный гимн Беларуси</a>
        </li>
        <li>
          <a href="blr_flag.php">Национальный флаг Беларуси</a>
        </li>
        <li>
          <a href="polotsk_principality.php" class="item-edit">Полоцкое княжество</a>
        </li>
        <li>
          <a href="blr_gerb.php" class="item-edit">Погоня</a>
        </li>
        <li>
          <a href="religion_blr.php">Религия на белорусских землях</a>
        </li>
        <li>
          <a href="rzeczpospolita.php" class="item-edit">Речь Посполитая</a>
        </li>
		<li>
          <a href="rzeczpospolita_treh_narodov.php">Речь Посполитая Трех Народов</a>
        </li>
		<li>
          <a href="rb.php" class="item-edit">Республика Беларусь</a>
        </li>
        <li>
          <a href="ross_empire.php">Российская империя</a>
        </li>
        <li>
          <a href="sssr.php" class="item-edit">СССР</a>
        </li>
        <li>
          <a href="slavs.php">Славяне</a>
        </li>
		<li>
          <a href="statut.php">Статут ВКЛ</a>
        </li>
        <li>
          <a href="sewero_zapadny_kraj.php" class="item-edit">Северо-Западный край</a>
        </li>
        <li>
          <a href="turow_principality.php" class="item-edit">Туровское княжество</a>
        </li>
        <li>
          <a href="filomaty.php" class="item-edit">Филоматы</a>
        </li>
		<li>
          <a href="shliahta.php">Шляхта</a>
        </li>
		<li>
          <a href="#" class="item-unable">Шляхетская демократия</a>
        </li>
		<li>
          <a href="#" class="item-unable">Some link</a>
        </li>
		<li>
          <a href="#" class="item-unable">Some link</a>
        </li>
		<li>
          <a href="#" class="item-unable">Some link</a>
        </li>
		<li>
          <a href="#" class="item-unable">Some link</a>
        </li>		
        <li>
          <a href="#" class="item-unable">...</a>
        </li>
        <li>
          <a href="#" class="item-unable">Some link</a>
        </li>
      </ul>
	  </div>
	
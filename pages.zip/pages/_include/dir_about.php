
      <div class="col-md-2 left-bar">
      <ul>
      
        <h4>Помощь и партнерство</h4>
          
        <li>
        <a target="_blank" href="http://www.talaka.by/">
        	<img src="../../images/img-about/talaka.jpg" class="img-right-120"/></br>
		   Кропка збору неабыякавых людзей Talaka.by
		  </a>
        </li>
       </br>
        <li>
        	<img src="../../images/img-about/maps.jpg" class="img-right-120"/></br>
           <a target="_blank" href="https://www.facebook.com/pages/%D0%9C%D0%B0%D0%B9%D1%81%D1%82%D1%8D%D1%80%D0%BD%D1%8F-%D1%81%D1%82%D0%B0%D1%80%D0%B0%D0%B4%D0%B0%D1%9E%D0%BD%D1%96%D1%85-%D0%B3%D0%B5%D0%B0%D0%B3%D1%80%D0%B0%D1%84%D1%96%D1%87%D0%BD%D1%8B%D1%85-%D0%BC%D0%B0%D0%BF/527727034041838">
		   Майстэрня старадаўніх геаграфічных мап
		  </a>
        </li>
        </br>
        <li>
          <a target="_blank" href="http://daggir84.livejournal.com/">DAggir84</a>
        </li>
        </br>
        <li>
        <a target="_blank" href="http://budzma.by/">
        <img src="../../images/img-about/by_budzma.jpg" class="img-right-120"/></br>
          Будзьма беларусамi!</a>
        </li>
		</br>
        <li>
        <a target="_blank" href="http://vkl3d.com/">
        <img src="../../images/img-about/vkl3d_logo.jpg" class="img-right-120"/></br>
          ВКЛ, архитектура 3D</a>
        </li>

          <h4>В проекте участвуют</h4>

        <li>
          <a href="#" class="item-unable">Кристобаль Хозевич</a>
        </li>
        <li>
          <a target="_blank" href="https://twitter.com/IMrFreeman">Александр</a>,
		  </br>редактор <a href="https://twitter.com/Belbriefhistory">Твиттер-блога</a></a>
        </li>
        <li>
          <a target="_blank" href="https://www.facebook.com/aliaksei.kairys">Aliaksei Kairys</a>, историк, автор и эксперт текстов по темам
        </li>
        <li>
          <a target="_blank" href="http://www.talaka.by/user/555" >Ратмир Новиков</a>, программист-консультант
        </li>
        <li>
          <a href="#" class="item-unable">Some link</a>
        </li>
		<li>
          <a href="#" class="item-unable">Some link</a>
        </li>
        <li>
          <a href="#" class="item-unable">...</a>
        </li>
        <li>
          <a href="#" class="item-unable">Some link</a>
        </li>
      </ul>
	  </div>
	
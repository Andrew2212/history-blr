
      <div class="col-md-2 left-bar">
      <ul>
      
        <h4>Помощь и консультации</h4>
          
        <li>
        	<img src="../../images/img-about/talaka.jpg" class="img-right-120"/></br>
           <a href="http://www.talaka.by/">
		   Кропка збору неабыякавых людзей Talaka.by
		  </a>
        </li>
       
        <li>
        	<img src="../../images/img-about/maps.jpg" class="img-right-120"/></br>
           <a href="https://www.facebook.com/pages/%D0%9C%D0%B0%D0%B9%D1%81%D1%82%D1%8D%D1%80%D0%BD%D1%8F-%D1%81%D1%82%D0%B0%D1%80%D0%B0%D0%B4%D0%B0%D1%9E%D0%BD%D1%96%D1%85-%D0%B3%D0%B5%D0%B0%D0%B3%D1%80%D0%B0%D1%84%D1%96%D1%87%D0%BD%D1%8B%D1%85-%D0%BC%D0%B0%D0%BF/527727034041838">
		   Майстэрня старадаўніх геаграфічных мап
		  </a>
        </li>
        <li>
          <a href="http://daggir84.livejournal.com/">DAggir84</a>
        </li>

          <h4>В проекте принимали участие</h4>

        <li>
          <a href="#" class="item-unable">Кристобаль Хозевич</a>
        </li>
        <li>
          <a href="https://twitter.com/IMrFreeman">Александр</a>,
		  </br>редактор <a href="https://twitter.com/Belbriefhistory">Твиттер-блога</a></a>
        </li>
        <li>
          <a href="#" class="item-unable">Some link</a>
        </li>
        <li>
          <a href="#" class="item-unable">Some link</a>
        </li>
        <li>
          <a href="#" class="item-unable">Some link</a>
        </li>
		<li>
          <a href="#" class="item-unable">Some link</a>
        </li>
        <li>
          <a href="#" class="item-unable">...</a>
        </li>
        <li>
          <a href="#" class="item-unable">Some link</a>
        </li>
      </ul>
	  </div>
	
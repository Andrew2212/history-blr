
      <div class="col-md-2 left-bar">
      <ul>

          <h4>Топонимы</h4>

        <li>
          <a href="wilno.php" class="item-edit">Вильно</a>
        </li>
        <li>
          <a href="wostra_brama.php" class="item-edit">Вострая Брама</a>
        </li>
        <li>
          <a href="samogitia.php" class="item-edit">Летува (Lietuva) — Жемайтия (Самогития)</a>
        </li>
        <li>
          <a href="litwa.php" class="item-edit">Литва (Litvaniae, Lithuania)</a>
        </li>
        <li>
          <a href="kossowo.php" class="item-edit">Коссово</a>
        </li>
        <li>
          <a href="polotsk.php" class="item-edit">Полоцк</a>
        </li>
		<li>
          <a href="krapiwen_field.php" class="item-edit">Крапивенское поле</a>
        </li>
        <li>
          <a href="nowogrudok.php" class="item-edit">Новогрудок</a>
        </li>
        <li>
          <a href="sea_herodotus.php" class="item-edit">Море Геродота</a>
        </li>
        <li>
          <a href="#" class="item-unable">Some link</a>
        </li>
      </ul>
	  </div>
	

      <div class="col-md-2 left-bar">
      <ul>

          <h4>What for?</h4>

        <li>
          <a href="../articles/essay.php">Эссе на заданную тему</a>
        </li>
        <li>
          <a href="../figures/you.php" >Лично ТЫ</a>
        </li>
        <li>
          <a href="../download/blr_people.php">Карта белорусского этноса</a>
        </li>
        <li>
          <a href="../download/map_wkl_lotter.php" >Карта ВКЛ</a>
        </li>
        <li>
          <a href="../terms/statut.php">Статут ВКЛ</a>
        </li>
        <li>
          <a href="../terms/blr_gerb.php">Герб</a>
        </li>
        <li>
          <a href="../terms/blr_flag.php">Флаг</a>
        </li>
        <li>
          <a href="../terms/blr_hymn.php">Гимн</a>
        </li>
		<li>
          <a href="../events/fails.php">Неудачные попытки</a>
        </li>
        <li>
          <a href="../articles/book_mova.php">Хоршая горькая книга</a>
        </li>
        <li>
          <a href="#" class="item-unable">...</a>
        </li>
        <li>
          <a href="#" class="item-unable">Some link</a>
        </li>
      </ul>
	  </div>
	
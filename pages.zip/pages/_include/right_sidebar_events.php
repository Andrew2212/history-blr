
      <div class="col-md-2 right-bar">
    	<p>
			<img src="../../images/img-events/sinie_wody.jpg" class="img-right-120"/></br>
			<small><a href="sinie_wody.php">Битва на Синих Водах</a> 1362 г.</small></br></br>
	   </p>
	   <p>
			<img src="../../images/img-events/unia_krewo.jpg" class="img-right-120"/></br>
			<small><a href="unia_krewo.php">Кревская уния</a> 1385 г.</small></br></br>
	   </p>
	   	<p>
			<img src="../../images/img-events/grunwald.jpg" class="img-right-120"/></br>
			<small><a href="grunwald.php">Грюнвальдская битва</a> 1410 г.</small></br></br>
	   </p>
	   <p>
			<img src="../../images/img-events/unia_liublin_paper.jpg" class="img-right-120"/></br>
			<small><a href="unia_liublin.php">Люблинская уния</a> 1569 г.</small></br></br>
	   </p>
	   	<p>
			<img src="../../images/img-events/potop.jpg" class="img-right-120"/></br>
			<small><a href="blood_potop.php">Кровавый Потоп</a> 1655-1660 г.</small></br></br>
	   </p>	 
	   	<p>
			<img src="../../images/img-events/razbor_rechi.jpg" class="img-right-120"/></br>
			<small><a href="razbor_rechi.php">Разделы Речи Посполитой</a> 1772-1795 г.</small></br></br>
	   </p>	   
		<p>
			<img src="../../images/img-events/uprising_1830.jpg" class="img-right-120"/></br>
			<small><a href="uprising_1830.php">Восстание 1830 г.</a></small></br></br>
	   </p>
	  </div>
	
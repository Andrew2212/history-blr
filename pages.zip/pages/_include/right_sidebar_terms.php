
      <div class="col-md-2 right-bar">
	   <p>
			<img src="../../images/img-terms/pogonia.jpg" class="img-right-120"/></br>
			<small><a href="pogonia.php">Погоня</a> (знак с пограничного столба Республики Беларусь, 1995 г.)</small></br></br>
	   </p>
	   <p>
			<img src="../../images/img-terms/statut.jpg" class="img-right-120"/></br>
			<small><a href="statut.php">Статут ВКЛ</a></small></br></br>
	   </p>
	   	<p>
			<img src="../../images/img-terms/shliahta_wkl.jpg" class="img-right-120"/></br>
			<small><a href="shliahta.php">Шляхта</a></small></br></br>
	   </p>
	   	<p>
			<img src="../../images/img-terms/litvin.jpg" class="img-right-120"/></br>
			<small><a href="litwiny.php">Литвины</a></small></br></br>
	   </p>	 
	   	<p>
			<img src="../../images/img-terms/hetman_wkl.jpg" class="img-right-120"/></br>
			<small><a href="weliki_hetman.php">Великий гетман Литовский</a></small></br></br>
	   </p>
	   	<p>
			<img src="../../images/img-terms/kancler_wkl.jpg" class="img-right-120"/></br>
			<small><a href="weliki_kancler.php">Великий канцлер Литовский</a></small></br></br>
	   </p>	   
		<p>
			<img src="../../images/img-terms/marshalok_wkl.jpg" class="img-right-120"/></br>
			<small><a href="weliki_marshalok.php">Великий маршалок Литовский</a></small></br></br>
	   </p>
	   		<p>
			<img src="../../images/img-terms/husaria.jpg" class="img-right-120"/></br>
			<small><a href="husaria.php">Крылатые гусары</a></small></br></br>
	   </p>
	  </div>
	
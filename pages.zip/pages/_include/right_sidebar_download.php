
      <div class="col-md-2 right-bar">
    	<p>
			<img src="../../images/img-download/map_Lotter_litwa_1770_thumb.jpg" class="img-right-120"/></br>
			<small><a href="map_wkl_lotter.php">карта ВКЛ</a> Тобиаса Лоттера</small>, 1770 г.</br></br>
	   </p> 
      	<p>
			<img src="../../images/img-download/metrica_litwa.jpg" class="img-right-120"/></br>
			<small><a href="metrica_litwa.php">Метрики Литовские</a></small></br></br>
	   </p>
	   <p>
			<img src="../../images/img-download/voisko_wkl.jpg" class="img-right-120"/></br>
			<small><a href="spis_voiska.php">Перепись войска Литовского 1528 г.</a></small></br></br>
	   </p>
	   <p>
			<img src="../../images/img-download/map_nikola_radziwill_thumb.jpg" class="img-right-120"/></br>
			<small><a href="map_radziwill.php">Карта ВКЛ</a> Никоая Криштофа Радзивилла, 1630 г.</small></br></br>
	   </p>
	   <p>
			<img src="../../images/img-download/map_blr_people_thumb.jpg" class="img-right-120"/></br>
			<small>Этнографическая <a href="blr_people.php">карта </a> белорусского племени, 1903 г.</small></br></br>
	   </p> 
	   <p>
			<img src="../../images/img-download/rp_16_vek_nac_thumb.jpg" class="img-right-120"/></br>
			<small>Подробная <a href="wkl_rp_belarus_16vek.php">карта Беларуси-ВКЛ</a> в составе Речи Посполитой</small></br></br>
	   </p> 

	  </div>
	
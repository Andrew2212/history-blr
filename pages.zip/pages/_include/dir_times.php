
      <div class="col-md-2  left-bar">
      <ul>

          <h4>Время</h4>

        <li>
          <a href="10_vek.php" class="item-link">X век</a>
        </li>
        <li>
          <a href="11_vek.php" class="item-link">XI век</a>
        </li>
        <li>
          <a href="12_vek.php" class="item-link">XII век</a>
        </li>
        <li>
          <a href="13_vek.php" class="item-link">XIII век</a>
        </li>
        <li>
          <a href="14_vek.php" class="item-link">XIV век</a>
        </li>
        <li>
          <a href="15_vek.php" >XV век</a>
        </li>
        <li>
          <a href="16_vek.php" class="item-link">XVI век</a>
        </li>
		<li>
          <a href="17_vek.php">XVII век</a>
        </li>
        <li>
          <a href="18_vek.php">XVIII век</a>
        </li>
        <li>
          <a href="#" class="item-unable">XIX век</a>
        </li>
		<li>
          <a href="#" class="item-unable">XX век</a>
        </li>
		<li>
          <a href="21_vek.php">XXI век</a>
        </li>
      </ul>
	  </div>
	
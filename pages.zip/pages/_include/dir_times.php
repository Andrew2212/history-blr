
      <div class="col-md-2  left-bar">
      <ul>

          <h4>Время</h4>

        <li>
          <a href="#" class="item-unable">X век</a>
        </li>
        <li>
          <a href="#" class="item-unable">XI век</a>
        </li>
        <li>
          <a href="#" class="item-unable">XII век</a>
        </li>
        <li>
          <a href="#" class="item-unable">XIII век</a>
        </li>
        <li>
          <a href="#" class="item-unable">XIV век</a>
        </li>
        <li>
          <a href="15_vek.php" class="item-edit">XV век</a>
        </li>
        <li>
          <a href="16_vek.php" class="item-edit">XVI век</a>
        </li>
		<li>
          <a href="#" class="item-unable">XVII век</a>
        </li>
        <li>
          <a href="#" class="item-unable">XVIII век</a>
        </li>
        <li>
          <a href="#" class="item-unable">XIX век</a>
        </li>
		<li>
          <a href="#" class="item-unable">XX век</a>
        </li>
		<li>
          <a href="21_vek.php">XXI век</a>
        </li>
      </ul>
	  </div>
	
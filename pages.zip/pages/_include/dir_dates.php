
      <div class="col-md-2 left-bar">
	   <p>
			<img src="../../img/logo_stub.png" class="img-right-120"/></br>
			<small>Подпись <a href="#">ссылка</a></small></br></br>
	   </p>
	   <p>
			<img src="../../img/logo_stub.png" class="img-right-120"/></br>
			<small>Подпись <a href="#">ссылка</a></small></br></br>
	   </p>
	   	<p>
			<img src="../../img/logo_stub.png" class="img-right-120"/></br>
			<small>Подпись <a href="#">ссылка</a></small></br></br>
	   </p>
	   	<p>
			<img src="../../img/logo_stub.png" class="img-right-120"/></br>
			<small>Подпись <a href="#">ссылка</a></small></br></br>
	   </p>	 
	   	<p>
			<img src="../../img/logo_stub.png" class="img-right-120"/></br>
			<small>Подпись <a href="#">ссылка</a></small></br></br>
	   </p>
	   	<p>
			<img src="../../img/logo_stub.png" class="img-right-120"/></br>
			<small>Подпись <a href="#">ссылка</a></small></br></br>
	   </p>	   
		<p>
			<img src="../../img/logo_stub.png" class="img-right-120"/></br>
			<small>Подпись <a href="#">ссылка</a></small></br></br>
	   </p>
	  </div>
	
﻿
      <div class="col-md-2 right-bar" >
	   <p>
			<img src="../../images/img-times/kalumny.png" class="img-right-120"/></br>
			<small><a href="../terms/polotsk_principality.php">"Калюмны"</a>. Гербовый знак 
			<a href="../terms/polotsk_principality.php">Полоцкого княжества</a> до 1386 г.</small></br></br>
	   </p>
	   <p>
			<img src="../../images/img-times/gerb_WKL.png" class="img-right-120"/></br>
			<small><a href="../terms/pogonia.php">«Погоня»</a>. Герб 
			<a href="../terms/wkl.php">Великого княжества Литовского</a></small></br></br>
	   </p>
	   	<p>
			<img src="../../images/img-times/gerb_rechypospolitey.jpg" class="img-right-120" /></br>
			<small>Герб <a href="../terms/rzeczpospolita.php">Речи Посполитой</a></small></br></br>
	   </p>
	   <p>
			<img src="../../images/img-times/gerb_inRI.jpg" class="img-right-120" /></br>
			<small>На Большом гербе <a href="../terms/ross_empire.php">Российской империи</a></small></br></br>
	   </p>
	   	<p>
			<img src="../../images/img-times/gerb_BNR.gif" class="img-right-120" /></br>
			<small>Герб <a href="../terms/bnr.php">БНР</a>, 1918 г.</small></br></br>
	   </p>	 
	   	<p>
			<img src="../../images/img-times/gerb_BSSR.png" class="img-right-120" /></br>
			<small>Герб <a href="../terms/bssr.php">БССР</a>, 1950 г.</small></br></br>
	   </p>
	   	<p>
			<img src="../../images/img-times/gerb_RB.png" class="img-right-120" /></br>
			<small>Герб <a href="../terms/rb.php">РБ</a>, 1991 г.</small></br></br>
	   </p>	   

	  </div>
	
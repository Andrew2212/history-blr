<?PHP  header("Content-Type: text/html; charset=utf-8");?>
<!DOCTYPE html>
<html lang="ru">
  <head>

<!-- ***Include Header*** -->
<? include ("../_include/header_times.php"); ?>
  
  <!-- ***Content & Sidebars*** -->
  <div class="container-fluid">
  

      <!-- ***Sidebar Left - include CurrentDir*** -->
<? include ("../_include/dir_times.php"); ?>

	
    <!-- ***Page Content*** -->
    <div class="col-md-8">

	<h3>XV век</h3>

	 <div class="col-md-12">
		<p>
		Эта страница требует вашего участия
		</p>
	</div>	
		
	</div>
	
	<!-- ***Sidebar Right*** -->
	<? include ("../_include/right_sidebar_times.php"); ?>

	
</div>

<!-- ***Include Footer*** -->
<? include ("../_include/footer.php"); ?>
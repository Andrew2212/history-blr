<?PHP  header("Content-Type: text/html; charset=utf-8");?>
<!DOCTYPE html>
<html lang="ru">
  <head>

<!-- ***Include Header*** -->
<? include ("../_include/header_times.php"); ?>
  
  <!-- ***Content & Sidebars*** -->
  <div class="container-fluid">
  

      <!-- ***Sidebar Left - include CurrentDir*** -->
<? include ("../_include/dir_times.php"); ?>

	
    <!-- ***Page Content*** -->
    <div class="col-md-8">

	<h3>XVI век</h3>

	 <div class="col-md-12">
		<p>
		Эта страница требует вашего участия
		</p>
	</div>
	<p>
	Исторические карты белорусских земель XVI века можно посмотреть <a href="../download/map_16century.php">тут </a>
	</p>
	
		<p class="img-float-center">
			<img src="../../images/img-places/litwa/Goroda VKL_Rus.jpg"/>
		</p>	
		
	</div>
	
	<!-- ***Sidebar Right*** -->
	<? include ("../_include/right_sidebar_times.php"); ?>

	
</div>

<!-- ***Include Footer*** -->
<? include ("../_include/footer.php"); ?>
<?PHP  header("Content-Type: text/html; charset=utf-8");?>
<!DOCTYPE html>
<html lang="ru">
  <head>

<!-- ***Include Header*** -->
<? include ("../_include/header_times.php"); ?>
  
  <!-- ***Content & Sidebars*** -->
  <div class="container-fluid">
  

      <!-- ***Sidebar Left - include CurrentDir*** -->
<? include ("../_include/dir_times.php"); ?>

	
    <!-- ***Page Content*** -->
    <div class="col-md-8">

	<h3>XXI век</h3>

	 <div class="col-md-12">
		<img src="../../images/img-times/21_vek/santaiana.jpg" class="img-float-left"/>
		<i>
		<h4>Народы, не знающие своей истории, обречены пережить ее снова.</h4>
		<h4>Ногами человек должен врасти в землю своей родины, но глаза его пусть обозревают весь мир.</h4>
		</i>
		<p>
		Джордж Сантаяна
		</p>
	</div>

	<div class="col-md-12">
		<p>
		</br></br>
		<h4>Материал для этой страницы готовите вы, но напишут ее ваши внуки.</h4>
		<i>Si Deus Nobiscum quis contra nos</i>
		</p>
	</div>	
		
	</div>
	
	<!-- ***Sidebar Right*** -->
	<? include ("../_include/right_sidebar_times.php"); ?>

	
</div>

<!-- ***Include Footer*** -->
<? include ("../_include/footer.php"); ?>
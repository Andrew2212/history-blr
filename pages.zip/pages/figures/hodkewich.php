<?PHP  header("Content-Type: text/html; charset=utf-8");?>
<!DOCTYPE html>
<html lang="ru">
  <head>

<!-- ***Include Header*** -->
<? include ("../_include/header_figures.php"); ?>
  
  <!-- ***Content & Sidebars*** -->
  <div class="container-fluid">
  

      <!-- ***Sidebar Left - include CurrentDir*** -->
<? include ("../_include/dir_figures.php"); ?>

	
    <!-- ***Page Content*** -->
    <div class="col-md-8">
		<h3>Ходкевичи, воины великого княжества</h3>
		<p>
			Статья в разработке</br></br>
			Иван Федорович Ходкевич Гетманы великие литовские 1476—?
			Григорий Александрович Ходкевич — Гетманы великие литовские 1566—1572
			Ян Иеронимович Ходкевич Маршалки великие литовские (1574—1579)
			Ян Кароль Ходкевич Гетманы великие литовские 1605—1621
		
		
		</p>
	</div>
	
	<!-- ***Sidebar Right*** -->

	<? include ("../_include/right_sidebar_figures.php"); ?>

	
</div>

<!-- ***Include Footer*** -->
<? include ("../_include/footer.php"); ?>
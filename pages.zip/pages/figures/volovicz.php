<?PHP  header("Content-Type: text/html; charset=utf-8");?>
<!DOCTYPE html>
<html lang="ru">
  <head>

<!-- ***Include Header*** -->
<? include ("../_include/header_figures.php"); ?>
  
  <!-- ***Content & Sidebars*** -->
  <div class="container-fluid">
  

      <!-- ***Sidebar Left - include CurrentDir*** -->
<? include ("../_include/dir_figures.php"); ?>

	
    <!-- ***Page Content*** -->
    <div class="col-md-8">
		<h3>Остафий Волович
		</br><small>Воловичи, шляхетский род</small></h3>
		<p>
			Статья на 6000 знаков (с пробелами)</br></br>
			Остафий Волович (1579-1587) в. канцлер
			Мартиан Доминик Волович (1734) в. маршалок
		</p>
		
		</br></br></br>
		<p><small>
		be-x-old.wikipedia.org</br>
		be.wikipedia.org</br>
		pl.wikipedia.org</br>
		uk.wikipedia.org</br>
		ru.wikipedia.org</br>
		inbelhist.org/?p=4737
		</small></p>
	</div>
	
	<!-- ***Sidebar Right*** -->

	<? include ("../_include/right_sidebar_figures.php"); ?>

	
</div>

<!-- ***Include Footer*** -->
<? include ("../_include/footer.php"); ?>
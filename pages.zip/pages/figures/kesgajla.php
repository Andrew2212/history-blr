<?PHP  header("Content-Type: text/html; charset=utf-8");?>
<!DOCTYPE html>
<html lang="ru">
  <head>

<!-- ***Include Header*** -->
<? include ("../_include/header_figures.php"); ?>
  
  <!-- ***Content & Sidebars*** -->
  <div class="container-fluid">
  

      <!-- ***Sidebar Left - include CurrentDir*** -->
<? include ("../_include/dir_figures.php"); ?>

	
    <!-- ***Page Content*** -->
    <div class="col-md-8">
		<h3>Судзивой Волимонтович</h3>
		<p>
	— государственный деятель Великого княжества Литовского. 
	Насместник смоленский (в неизвестный точно время между 1441 и 1448), наместник ковенский (1450-1451), канцлер великий литовский (1441), 
	каштелян виленский (1451 - не позднее 1458).
	</br>Происходит из литвинского боярского рода, сын Валимонта Бушковича из Вилькомирского уезда. 
	</br>Вилькомир — город в Летуве на реке Святая. После того, как 
	в 1920 году город перешел к Летуве, он был преименован в Укмерге.   		
		</p>
		<p>
		Брат Судзивоя Волимонтович, Кезгайло, положил начало влиятельному литвинскому магнатскому роду —<h3>Кезгайлы </h3>
		</p>
		<p>
		Сын Кезгайло, Михаил — 
		<h4>Михаил Кезгайлович</h4> или Михаил Кезгайло — государственный деятель Великого княжества Литовского, 
		канцлер великий литовский с 1492 года, воевода виленский с 1458 года по 1459 год, наместник смоленский c 1451 года по 1458 год.
		</p>
	</div>
	
	
		</br></br></br>
		<p><small>
		be-x-old.wikipedia.org</br>
		be.wikipedia.org</br>
		pl.wikipedia.org</br>
		uk.wikipedia.org</br>
		ru.wikipedia.org</br>
		</small></p>
	
	<!-- ***Sidebar Right*** -->

	<? include ("../_include/right_sidebar_figures.php"); ?>

	
</div>

<!-- ***Include Footer*** -->
<? include ("../_include/footer.php"); ?>
<?PHP  header("Content-Type: text/html; charset=utf-8");?>
<!DOCTYPE html>
<html lang="ru">
  <head>

<!-- ***Include Header*** -->
<? include ("../_include/header_figures.php"); ?>
  
  <!-- ***Content & Sidebars*** -->
  <div class="container-fluid">
  

      <!-- ***Sidebar Left - include CurrentDir*** -->
<? include ("../_include/dir_figures.php"); ?>

	
    <!-- ***Page Content*** -->
    <div class="col-md-8">
		<h3>Иван Федоров, первопечатник в Московии и Украине</h3>
		<p>
			Генеалогическая трактовка его типографского знака, тождественного с гербом белорусского шляхетского рода Рагоза, 
			дает основания предполагать о его связи с этим родом либо по происхождению, 
			либо в результате приписки к гербу «Шренява»; 
			к этому гербу принадлежало несколько десятков белорусских, украинских и польских фамилий. 
			Его род происходил из Петковичей, на границе современной Минской и Брестской областей.
		
		</p>
		<p>
		Статья в разработке
		</p>
		
		</br></br></br>
		<p><small>
		be-x-old.wikipedia.org</br>
		be.wikipedia.org</br>
		pl.wikipedia.org</br>
		uk.wikipedia.org</br>
		ru.wikipedia.org</br>
		</small></p>
		
	</div>
	
	<!-- ***Sidebar Right*** -->

	<? include ("../_include/right_sidebar_figures.php"); ?>

	
</div>

<!-- ***Include Footer*** -->
<? include ("../_include/footer.php"); ?>
<?PHP  header("Content-Type: text/html; charset=utf-8");?>
<!DOCTYPE html>
<html lang="ru">
  <head>

<!-- ***Include Header*** -->
<? include ("../_include/header_figures.php"); ?>
  
  <!-- ***Content & Sidebars*** -->
  <div class="container-fluid">
  

      <!-- ***Sidebar Left - include CurrentDir*** -->
<? include ("../_include/dir_figures.php"); ?>

	
    <!-- ***Page Content*** -->
    <div class="col-md-8">
		<h3>Максимилиан Станислав Рылло</h3>
		<p>
		Родился в деревне на Гродненщине в обедневшей шляхетской семье. В 1817 году окончил школу в деревне Лысково Пружанского уезда, затем Полоцкую иезуитскую академию, получив степень магистра философии. В 1820 году поступил на медицинский факультет Виленского университета. В связи с запрещением в Российской империи деятельности иезуитов, уехал в Рим, где в 1824—1826 и в 1830—1834 гг. продолжил учёбу в Папском Григорианском университете, изучая философию и теологию. Получил звание профессора философии. Преподавал в иезуитских школах
		</p>
		<p>
		Первым из исследователей ознакомился с отстатками древнего Вавилона, подарив музею Ватикана коллекцию археологических находок. В 1837 году избран в папскую археологическую академию и Ориентологическое товарищество Франции		
		</p>
		<p>
		Статья в разработке
		</p>
		
		</br></br></br>
		<p><small>
		be-x-old.wikipedia.org</br>
		be.wikipedia.org</br>
		pl.wikipedia.org</br>
		uk.wikipedia.org</br>
		ru.wikipedia.org</br>
		</small></p>
		
	</div>
	
	<!-- ***Sidebar Right*** -->

	<? include ("../_include/right_sidebar_figures.php"); ?>

	
</div>

<!-- ***Include Footer*** -->
<? include ("../_include/footer.php"); ?>
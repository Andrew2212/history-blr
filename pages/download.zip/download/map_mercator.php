<?PHP  header("Content-Type: text/html; charset=utf-8");?>
<!DOCTYPE html>
<html lang="ru">
  <head>

<!-- ***Include Header*** -->
<? include ("../_include/header_download.php"); ?>
  
  <!-- ***Content & Sidebars*** -->
  <div class="container-fluid">
  

      <!-- ***Sidebar Left - include CurrentDir*** -->
<? include ("../_include/dir_download.php"); ?>

	
    <!-- ***Page Content*** -->
    <div class="col-md-8">
		<h3>Герард Меркатор, Lithvania, 1595</h3>
		<p>
		<i>
		Узнать больше можно 
		<a href="https://www.facebook.com/pages/%D0%9C%D0%B0%D0%B9%D1%81%D1%82%D1%8D%D1%80%D0%BD%D1%8F-%D1%81%D1%82%D0%B0%D1%80%D0%B0%D0%B4%D0%B0%D1%9E%D0%BD%D1%96%D1%85-%D0%B3%D0%B5%D0%B0%D0%B3%D1%80%D0%B0%D1%84%D1%96%D1%87%D0%BD%D1%8B%D1%85-%D0%BC%D0%B0%D0%BF/527727034041838">
		тут
		</a>
		</i>
		</p>

		
		<div class="col-md-12">
			<p>
			</br>
			<img src="../../images/img-download/16_vek/1595_Mercator_Lithuania_thumb.jpg" class="img-float-left"/>
			1595, Герард Меркатор, Lithvania
			</br>Самая классическая классика:
			</br>— самый первый Атлас (сборник карт мира с атлантом на обложке)
			</br>— самая первая карта,посвященная <i>только </i>белорусским землям.
			</br> Подробнее <a href="http://yan-k.livejournal.com/64842.html?thread=1433162">тут</a>
			</p>
			<p>
			Размер 3000 х 2500</br>
			<a href="https://drive.google.com/file/d/0B_T3PThCY39DblZCdmZtRFk0bHc/view?usp=sharing" class="btn btn-default img-float-left"
						data-toggle="modal"> <i class="glyphicon glyphicon-cloud-download"></i> Посмотреть и скачать</a>
			</p>
		</div>
		
	</div>
	
	<!-- ***Sidebar Right*** -->

	<? include ("../_include/right_sidebar_download.php"); ?>

	
</div>

<!-- ***Include Footer*** -->
<? include ("../_include/footer.php"); ?>
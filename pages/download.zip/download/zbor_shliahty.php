<?PHP  header("Content-Type: text/html; charset=utf-8");?>
<!DOCTYPE html>
<html lang="ru">
  <head>

<!-- ***Include Header*** -->
<? include ("../_include/header_download.php"); ?>
  
  <!-- ***Content & Sidebars*** -->
  <div class="container-fluid">
  

      <!-- ***Sidebar Left - include CurrentDir*** -->
<? include ("../_include/dir_download.php"); ?>

	
    <!-- ***Page Content*** -->
    <div class="col-md-8">
		<h3>Собрание имен шляхты Польши и ВКЛ, 1805 г.</h3>
			<p>
			<img src="../../images/img-download/zbor_names.jpg" class="img-float-left"/>
			При поиске фамилии можно пользоваться переводом белорусского написания на 
			<a href="http://be.wikipedia.org/wiki/%D0%91%D0%B5%D0%BB%D0%B0%D1%80%D1%83%D1%81%D0%BA%D1%96_%D0%BB%D0%B0%D1%86%D1%96%D0%BD%D1%81%D0%BA%D1%96_%D0%B0%D0%BB%D1%84%D0%B0%D0%B2%D1%96%D1%82">
			лацінку	
			</a>
			</p>


			<p>
			Файл PDF</br>
			<a href="https://drive.google.com/file/d/0B_T3PThCY39DeGtvcXVTc2hxaWc/view?usp=sharing" class="btn btn-default img-float-left"
						data-toggle="modal"> <i class="glyphicon glyphicon-cloud-download"></i> Посмотреть и скачать</a>
			</p>
			<p>
			Смотреть на 
			<a href="http://books.google.by/books?id=iIIfAAAAYAAJ&printsec=frontcover&hl=ru&source=gbs_ge_summary_r&cad=0#v=onepage&q&f=false">
			 books.google
			</a>
			</p>
	</div>
	
	<!-- ***Sidebar Right*** -->

	<? include ("../_include/right_sidebar_download.php"); ?>

	
</div>

<!-- ***Include Footer*** -->
<? include ("../_include/footer.php"); ?>